from controller import Supervisor

supervisor = Supervisor()
timestep = int(supervisor.getBasicTimeStep())

caja = supervisor.getFromDef("caja")
caja2 = supervisor.getFromDef("caja2")

pos1_field = caja.getField("translation")
pos2_field = caja2.getField("translation")

desired_distance = 0.15
k = 200  # Fuerza más alta
max_force = 1000  # Límite para que no explote

while supervisor.step(timestep) != -1:
    p1 = pos1_field.getSFVec3f()
    p2 = pos2_field.getSFVec3f()

    dx = p1[0] - p2[0]
    dy = p1[1] - p2[1]
    dz = p1[2] - p2[2]

    dist = (dx**2 + dy**2 + dz**2)**0.5

    if dist > desired_distance:
        force_mag = min(k * (dist - desired_distance), max_force)
        fx = dx / dist * force_mag
        fy = dy / dist * force_mag
        fz = dz / dist * force_mag
        caja2.addForce([fx, fy, fz], False)

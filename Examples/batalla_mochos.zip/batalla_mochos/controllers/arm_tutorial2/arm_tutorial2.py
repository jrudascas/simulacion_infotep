from controller import Robot

robot=Robot()
timestep=64

m=robot.getDevice("motor2")
m.setPosition(float('inf'))
m.setVelocity(0.0)

pSensor=robot.getDevice("ps2")
pSensor.enable(timestep)

speed=5.5
k=0

while (robot.step(timestep) !=-1):
    m.setVelocity(speed)
    k=pSensor.getValue()